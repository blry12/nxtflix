import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://auraflix.io/nxtflix/texts/Omega_Builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://auraflix.io/nxtflix/texts/wizard_notify_omega.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
