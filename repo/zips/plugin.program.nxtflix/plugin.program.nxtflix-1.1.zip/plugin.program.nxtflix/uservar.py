import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://the666mafia.com/nxtflix/txt/maintance.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://the666mafia.com/nxtflix/txt/maintance.xml'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
