import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://auraflix.io/nxtflix/texts/Builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://auraflix.io/nxtflix/texts/Builds.xml'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
